﻿/* Safe DOM construction; explicit state and API error paths. */
let activePlan=null, reviewToken=null;
const main=document.querySelector('main');
const policyLabel=textEl('label','Allocation method');policyLabel.htmlFor='policy';const policySelect=textEl('select','');policySelect.id='policy';policySelect.append(new Option('Transparent greedy','greedy'),new Option('Static weighted-coverage MILP','milp'));$('plan').before(policyLabel,policySelect);
function section(title){const el=textEl('section','');el.append(textEl('h2',title));main.append(el);return el;}
function action(parent,label,fn){const b=textEl('button',label);b.type='button';b.onclick=()=>perform(b,fn);parent.append(b);return b;}
function pre(parent){const p=textEl('pre','');parent.append(p);return p;}
function labelled(parent,label,id,value){const l=textEl('label',label);l.htmlFor=id;const i=textEl('textarea','');i.id=id;i.value=value;parent.append(l,i);return i;}
const dataSection=section('Data registry and import preview');
const ds=textEl('select','');ds.id='datasetChoice';const dl=textEl('label','Registered dataset');dl.htmlFor=ds.id;dataSection.append(dl,ds);
const lineage=pre(dataSection);
action(dataSection,'Refresh registry',async()=>{const v=await api('/api/datasets');ds.replaceChildren();v.available.forEach(d=>ds.append(new Option(d.kind+' · '+d.version,d.version)));lineage.textContent=JSON.stringify(v,null,2);});
action(dataSection,'Use selected dataset',async()=>{await api('/api/datasets/'+encodeURIComponent(ds.value)+'/select',{method:'POST'});location.reload();});
dataSection.append(textEl('p','Import preview: run python -m scripts.import_uci <source> --preview. Publish with explicit --quarantine. The quality report above shows retained, rejected, cancellation and duplicate accounting. Raw customer fields are never served.'));
const chartSection=section('Product evidence · dates and recorded units');
const chartRoot=textEl('div','Inspect a product to display recorded sales and forecast.');chartSection.append(chartRoot);
function chart(values){chartRoot.replaceChildren();if(!values.length){chartRoot.textContent='No data available.';return;}
 const ns='http://www.w3.org/2000/svg', svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 720 220');svg.setAttribute('role','img');svg.setAttribute('aria-label','Recorded units in blue, forecast units in green; dates on horizontal axis');
 const max=Math.max(1,...values.map(v=>v.units));
 ['history','forecast'].forEach((type,j)=>{const pts=values.map((v,i)=>({v,i})).filter(x=>x.v.type===type).map(x=>`${45+x.i*650/Math.max(1,values.length-1)},${180-x.v.units/max*150}`).join(' ');const poly=document.createElementNS(ns,'polyline');poly.setAttribute('points',pts);poly.setAttribute('stroke',j?'#087b76':'#174d9c');poly.setAttribute('stroke-width','3');poly.setAttribute('fill','none');svg.append(poly);});
 [[10,20,Math.ceil(max)+' units'],[45,210,values[0].date],[570,210,values.at(-1).date]].forEach(([x,y,t])=>{const e=document.createElementNS(ns,'text');e.setAttribute('x',x);e.setAttribute('y',y);e.textContent=t;svg.append(e);});chartRoot.append(svg,textEl('p','Blue: recorded sales units · Green: forecast units · Calendar dates. Missing days are assumed zero recorded sales.'));
}
$('forecast').addEventListener('click',async()=>{try{const r=await api('/api/forecast/'+encodeURIComponent($('sku').value));chart([...r.history.map(v=>({...v,type:'history'})),...r.forecast.map(v=>({...v,type:'forecast'}))]);}catch(e){chartRoot.textContent=e.message;}});
const lab=section('Scenario lab · forecast × purchasing policy');
lab.append(textEl('p','All costs, inventory, lead times and cash grants are assumptions in GBP pence. Every policy receives the same recorded-sales proxy and seed. Weekly grants; paid orders arrive on a future day.'));
const scenario=labelled(lab,'Scenario JSON','scenario',JSON.stringify({days:14,budget_pence:20000,capacity_units:1000,initial_stock:20,unit_cost_pence:100,holding_pence:1,shortfall_pence:200,order_cost_pence:50,lead_days:3,pack:2,moq:4,variability:0,seed:2026},null,2));
const comparison=textEl('div','No comparison yet.');lab.append(comparison);
action(lab,'Compare policies',async()=>{comparison.textContent='Running common scenarios…';const v=await api('/api/compare',{method:'POST',headers:{'Content-Type':'application/json'},body:scenario.value});comparison.replaceChildren();const wrap=textEl('div','');wrap.className='scroll';const table=textEl('table','');const tr=textEl('tr','');['Forecast','Policy','Fill (filled / proxy units)','Scenario cost GBP','Mean stock units','Pareto'].forEach(t=>tr.append(textEl('th',t)));table.append(tr);v.results.forEach(r=>{const row=textEl('tr','');[r.method,r.policy,`${r.fulfilled_units} / ${r.proxy_demand_units} (${r.fill_rate===null?'undefined':(100*r.fill_rate).toFixed(1)+'%'})`,money(r.scenario_cost_pence),r.average_stock_units.toFixed(1),r.pareto?'yes':''].forEach(t=>row.append(textEl('td',t)));table.append(row);});wrap.append(table);comparison.append(wrap,textEl('p',v.limitations),textEl('pre','Dataset SHA-256: '+v.dataset_sha256));});
const reviews=section('Proposal history and human review');
reviews.append(textEl('p','Inspect the complete snapshot before confirmation. Local unauthenticated review provides no identity assurance and places no external order. Changing assumptions or data invalidates pending review.'));
const planId=labelled(reviews,'Saved proposal ID','planId','');planId.style.height='50px';
const reviewOutput=pre(reviews), historyOutput=textEl('div','No saved proposals loaded.');reviews.append(historyOutput);
action(reviews,'Refresh history',async()=>{const rows=await api('/api/plans');historyOutput.replaceChildren();if(!rows.length)historyOutput.textContent='No saved proposals.';rows.forEach(r=>action(historyOutput,r.created+' · '+(r.review||'Pending'),async()=>{planId.value=r.id;activePlan=await api('/api/plans/'+r.id);reviewOutput.textContent=JSON.stringify(activePlan,null,2);}));});
action(reviews,'Preview exact proposal',async()=>{const r=await api('/api/plans/'+encodeURIComponent(planId.value.trim())+'/review',{method:'POST'});activePlan=r.preview;reviewToken=r;reviewOutput.textContent=JSON.stringify(r,null,2);});
action(reviews,'Confirm inspected version locally',async()=>{if(!reviewToken||reviewToken.run_id!==planId.value.trim())throw Error('Preview this proposal first.');reviewOutput.textContent=JSON.stringify(await api('/api/confirm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:reviewToken.token,sha256:reviewToken.sha256})}),null,2);reviewToken=null;});
action(reviews,'Export CSV',async()=>{if(!planId.value.trim())throw Error('Select a saved proposal.');window.open('/api/plans/'+encodeURIComponent(planId.value.trim())+'/export?format=csv','_blank','noopener');});
action(reviews,'Open complete decision report',async()=>{if(!planId.value.trim())throw Error('Select a saved proposal.');window.open('/api/plans/'+encodeURIComponent(planId.value.trim())+'/export?format=report','_blank','noopener');});
action(reviews,'Save revised assumptions',async()=>{reviewOutput.textContent=JSON.stringify(await api('/api/assumptions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({budget_pence:Math.round(Number($('budget').value)*100),capacity_units:Number($('capacity').value),horizon_days:Number($('horizon').value),items:JSON.parse($('assumptions').value)})}),null,2);});
const assistantSection=section('Evidence assistant');
assistantSection.append(textEl('p','Read-only plan summaries with record citations. Without credentials: local rules / no LLM. Groq can select verified claims; numbers always come from saved records.'));
const question=labelled(assistantSection,'Question about the selected proposal','question','What cash is required and what remains uncovered?');question.style.height='80px';const assistantOutput=pre(assistantSection);
action(assistantSection,'Explain selected proposal',async()=>{const v=await api('/api/assistant',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:question.value,run_id:planId.value.trim()})});assistantOutput.textContent=v.mode+'\n'+v.status+'\n'+v.answer;});
const evaluationSection=section('Saved evaluation and uncertainty');const ev=pre(evaluationSection);
action(evaluationSection,'Load development evidence',async()=>{const v=await api('/api/evaluation');ev.textContent=JSON.stringify({stale_for_active_dataset:v.stale_for_active_dataset,provenance:v.provenance,protocol_sha256:v.protocol_sha256,summary:v.evaluation.summary,failures:v.evaluation.failures},null,2);});
const style=textEl('style',':focus-visible{outline:3px solid #a54b00;outline-offset:3px}svg{width:100%;max-height:300px}button{margin-right:8px}textarea{resize:vertical}th{vertical-align:top}');document.head.append(style);
